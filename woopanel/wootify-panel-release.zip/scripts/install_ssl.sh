#!/bin/bash
set -e

DOMAIN=$1
EMAIL=$2

if [ -z "$DOMAIN" ] || [ -z "$EMAIL" ]; then
    echo "Usage: $0 domain email"
    exit 1
fi

LOG_FILE="/var/log/wootify_ssl.log"
log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> $LOG_FILE
}

log "Starting SSL activation for $DOMAIN..."

source "$(dirname "$0")/os_detect.sh"

has_nginx_plugin() {
    certbot plugins 2>/dev/null | grep -q "nginx"
}

install_nginx_plugin() {
    if [ "$IS_DEBIAN" = true ]; then
        apt-get update
        apt-get install -y python3-certbot-nginx || apt-get install -y certbot python3-certbot-nginx
    elif [ "$IS_RHEL" = true ]; then
        $PKG_MANAGER install -y epel-release || true
        $PKG_MANAGER install -y python3-certbot-nginx || $PKG_MANAGER install -y certbot-nginx || $PKG_MANAGER install -y certbot python3-certbot-nginx
    fi
}

find_cert_names_by_domain() {
    certbot certificates 2>/dev/null | awk -v d="$DOMAIN" '
        /Certificate Name:/ {name=$3}
        /Domains:/ {
            for (i=2; i<=NF; i++) {
                if ($i == d || $i == "www." d) {
                    print name
                    break
                }
            }
        }
    ' | sort -u
}

# 1. Install Certbot
if ! command -v certbot &> /dev/null; then
    log "Installing Certbot..."
    if [ "$IS_DEBIAN" = true ]; then
        apt-get update
        apt-get install -y certbot python3-certbot-nginx
    elif [ "$IS_RHEL" = true ]; then
        $PKG_MANAGER install -y epel-release
        $PKG_MANAGER install -y certbot python3-certbot-nginx
    fi
fi

# Ensure nginx installer/authenticator plugin is available
if ! has_nginx_plugin; then
    log "Certbot nginx plugin missing. Installing plugin..."
    install_nginx_plugin
fi

if ! has_nginx_plugin; then
    log "Certbot nginx plugin still unavailable after installation attempt."
    echo "ERROR: NGINX_PLUGIN_MISSING"
    exit 1
fi

# Ensure deterministic behavior for recreated sites: remove existing cert lineages for this domain
EXISTING_CERTS=$(find_cert_names_by_domain || true)
if [ -n "$EXISTING_CERTS" ]; then
    log "Found existing certificate lineage(s) for $DOMAIN. Removing to avoid interactive renewal prompts..."
    while IFS= read -r CERT_NAME; do
        [ -z "$CERT_NAME" ] && continue
        certbot delete --cert-name "$CERT_NAME" --non-interactive || true
    done <<< "$EXISTING_CERTS"
fi

rm -f "/etc/letsencrypt/renewal/${DOMAIN}.conf" "/etc/letsencrypt/renewal/www.${DOMAIN}.conf"
rm -rf "/etc/letsencrypt/live/${DOMAIN}" "/etc/letsencrypt/archive/${DOMAIN}"

# 2. Request Certificate
# --nginx: Use Nginx plugin
# --non-interactive: No prompts
# --agree-tos: Agree to terms
# --redirect: Redirect HTTP to HTTPS
# --expand: Update existing cert if exists
log "Requesting Let's Encrypt certificate..."

# Capture output
set +e
OUTPUT=$(certbot --nginx -d "$DOMAIN" -d "www.$DOMAIN" \
    --non-interactive \
    --agree-tos \
    --email "$EMAIL" \
    --redirect \
    --expand \
    --cert-name "$DOMAIN" 2>&1)
RET=$?
set -e

if [ $RET -ne 0 ]; then
    log "Certbot failed with code $RET"
    echo "$OUTPUT" >> "$LOG_FILE"
    
    if echo "$OUTPUT" | grep -q "The domain name does not resolve to this machine"; then
        echo "ERROR: DNS_PROBLEM"
        exit 1
    elif echo "$OUTPUT" | grep -q "Challenge failed"; then 
        echo "ERROR: CHALLENGE_FAILED"
        exit 1
    elif echo "$OUTPUT" | grep -qi "requested nginx plugin does not appear to be installed\|could not select or initialize the requested installer nginx\|No candidate plugin"; then
        echo "ERROR: NGINX_PLUGIN_MISSING"
        exit 1
    else
        echo "ERROR: UNKNOWN"
        echo "$OUTPUT"
        exit 1
    fi
fi

# Get Expiry Date
EXPIRY_RAW=$(openssl x509 -enddate -noout -in "/etc/letsencrypt/live/$DOMAIN/cert.pem" 2>/dev/null | cut -d= -f2)
# Format might be: Feb 18 10:00:00 2026 GMT
# Convert to ISO 8601 if possible? date -d "$EXPIRY_RAW" +%Y-%m-%dT%H:%M:%SZ
if [ -n "$EXPIRY_RAW" ]; then
    EXPIRY_ISO=$(date -d "$EXPIRY_RAW" -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || echo "")
    echo "EXPIRY: $EXPIRY_ISO"
fi

# 4. Reload Nginx
systemctl reload nginx

# 5. Chuyển WordPress sang HTTPS (nếu site WordPress và có WP-CLI)
WEB_ROOT="/var/www/$DOMAIN"
if [ -f "$WEB_ROOT/wp-config.php" ] && command -v wp &> /dev/null; then
    log "WordPress detected. Checking site URL..."

    CURRENT_URL=$(wp option get siteurl --path="$WEB_ROOT" --allow-root 2>/dev/null || echo "")

    if [ -n "$CURRENT_URL" ] && echo "$CURRENT_URL" | grep -q "^http://"; then
        HTTPS_URL=$(echo "$CURRENT_URL" | sed 's|^http://|https://|')

        log "Updating siteurl: $CURRENT_URL -> $HTTPS_URL"
        wp option update siteurl "$HTTPS_URL" --path="$WEB_ROOT" --allow-root
        wp option update home "$HTTPS_URL" --path="$WEB_ROOT" --allow-root

        log "Search-replace database: http://$DOMAIN -> https://$DOMAIN"
        wp search-replace "http://$DOMAIN" "https://$DOMAIN" --path="$WEB_ROOT" --allow-root --skip-columns=guid --quiet || true
        wp search-replace "http://www.$DOMAIN" "https://www.$DOMAIN" --path="$WEB_ROOT" --allow-root --skip-columns=guid --quiet || true

        log "WordPress switched to HTTPS successfully."
    else
        log "Site URL already HTTPS or undetectable. Skipping."
    fi
fi

log "SSL activated successfully for $DOMAIN"
