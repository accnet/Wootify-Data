#!/bin/bash
set -e

# Arguments
DOMAIN=$1
WP_USER=$2
WP_PASS=$3
WP_EMAIL=$4
PHP_VERSION=${5:-"8.2"}

# Validate input
if [ -z "$DOMAIN" ] || [ -z "$WP_USER" ] || [ -z "$WP_PASS" ] || [ -z "$WP_EMAIL" ]; then
    echo "Usage: $0 domain wp_user wp_pass wp_email [php_version]"
    exit 1
fi

# Basic Email Validation Fallback
if [[ ! "$WP_EMAIL" == *"@"* ]]; then
    WP_EMAIL="admin@$DOMAIN"
fi

WEB_ROOT="/var/www/$DOMAIN"
LOG_FILE="/var/log/wootify_sites.log"

source "$(dirname "$0")/os_detect.sh"

# Default PHP Version Detection
if [ -z "$PHP_VERSION" ]; then
    PHP_VERSION=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;")
fi

log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> $LOG_FILE
}

trap 'echo "[ERROR] Site creation failed on line $LINENO"; exit 1' ERR

log "Starting creation for $DOMAIN (PHP $PHP_VERSION)..."

# 0. Generate Random Database Credentials
DB_SUFFIX=$(tr -dc a-z0-9 </dev/urandom | head -c 6)
DB_NAME="wp_${DB_SUFFIX}"
DB_USER="user_${DB_SUFFIX}"
DB_PASS=$(openssl rand -base64 12)

# 1. Install WP-CLI if missing
if ! command -v wp &> /dev/null; then
    log "Installing WP-CLI..."
    curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar > /dev/null 2>&1
    chmod +x wp-cli.phar
    mv wp-cli.phar /usr/local/bin/wp
fi

# 2. Create Web Directory
if [ -d "$WEB_ROOT" ]; then
    log "Directory $WEB_ROOT already exists. Backing up..."
    mv "$WEB_ROOT" "${WEB_ROOT}_bak_$(date +%s)"
fi
mkdir -p "$WEB_ROOT"
chown $WEB_USER:$WEB_GROUP "$WEB_ROOT"
chmod 755 "$WEB_ROOT"

# 3. Create Database
log "Creating Database $DB_NAME..."
mariadb -e "CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`;"
mariadb -e "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
mariadb -e "GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';"
mariadb -e "FLUSH PRIVILEGES;"

# 4. Download and Configure WordPress via WP-CLI
log "Installing WordPress Core..."

# Run as web user to ensure permissions
sudo -u $WEB_USER /usr/local/bin/wp core download --path="$WEB_ROOT" --quiet

sudo -u $WEB_USER /usr/local/bin/wp config create --dbname="$DB_NAME" --dbuser="$DB_USER" --dbpass="$DB_PASS" --path="$WEB_ROOT" --quiet

log "Installing WordPress Site..."
sudo -u $WEB_USER /usr/local/bin/wp core install --url="$DOMAIN" \
    --title="New WordPress Site" \
    --admin_user="$WP_USER" \
    --admin_password="$WP_PASS" \
    --admin_email="$WP_EMAIL" \
    --path="$WEB_ROOT" --quiet

# 5. Nginx Configuration
log "Configuring Nginx..."
NGINX_CONF="$NGINX_CONF_DIR/$DOMAIN.conf"

PHP_FPM_SOCK="/run/php/php$PHP_VERSION-fpm.sock"
if [ "$IS_RHEL" = true ]; then
    PHP_FPM_SOCK="/run/php-fpm/www.sock"
    # Check if a version-specific socket exists
    if [ -S "/run/php-fpm/php${PHP_VERSION//./}-php-fpm.sock" ]; then
        PHP_FPM_SOCK="/run/php-fpm/php${PHP_VERSION//./}-php-fpm.sock"
    fi
fi

cat > "$NGINX_CONF" <<EOF
server {
    listen 80;
    server_name $DOMAIN www.$DOMAIN;
    root $WEB_ROOT;
    index index.php index.html index.htm;

    # Logs
    access_log /var/log/nginx/${DOMAIN}_access.log;
    error_log /var/log/nginx/${DOMAIN}_error.log;

    location / {
        try_files \$uri \$uri/ /index.php?\$args;
    }

    location ~ \.php$ {
        fastcgi_pass unix:$PHP_FPM_SOCK;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.ht {
        deny all;
    }
}
EOF


# Check PHP-FPM Socket
if [ ! -S "$PHP_FPM_SOCK" ]; then
    log "Warning: Socket $PHP_FPM_SOCK missing. Restarting PHP-FPM..."
    if [ "$IS_DEBIAN" = true ]; then
        systemctl restart "php$PHP_VERSION-fpm" || true
    else
        systemctl restart php-fpm || true
    fi
    sleep 2
fi

# Link handled by RHEL conf.d or Debian sites-enabled
if [ "$IS_DEBIAN" = true ]; then
    NGINX_AVAILABLE="/etc/nginx/sites-available/$DOMAIN"
    mv "$NGINX_CONF" "$NGINX_AVAILABLE"
    ln -sf "$NGINX_AVAILABLE" "/etc/nginx/sites-enabled/$DOMAIN"
fi

# 6. Verify and Reload Nginx
if nginx -t; then
    systemctl reload nginx
    log "Nginx reloaded successfully."
else
    log "Nginx config test failed. Please check logs."
    rm "/etc/nginx/sites-enabled/$DOMAIN"
    exit 1
fi

# 7. Final Output (JSON for handler)
echo "{\"db_name\":\"$DB_NAME\", \"db_user\":\"$DB_USER\", \"db_pass\":\"$DB_PASS\"}"
log "Site $DOMAIN created successfully!"
