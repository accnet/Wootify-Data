#!/bin/bash

# ==================== OS DETECTION ====================
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    LIKE=$ID_LIKE
else
    echo "Hệ điều hành quá cũ hoặc không được hỗ trợ!"
    exit 1
fi

# Biến cờ (Flag) rút gọn
IS_DEBIAN=false
IS_RHEL=false

if [[ "$OS" == "ubuntu" || "$OS" == "debian" || "$LIKE" == *"debian"* ]]; then
    IS_DEBIAN=true
    PKG_MANAGER="apt-get"
    WEB_USER="www-data"
    WEB_GROUP="www-data"
    NGINX_CONF_DIR="/etc/nginx/sites-enabled"
elif [[ "$OS" == "centos" || "$OS" == "rhel" || "$OS" == "fedora" || "$OS" == "almalinux" || "$OS" == "rocky" || "$LIKE" == *"rhel"* || "$LIKE" == *"fedora"* ]]; then
    IS_RHEL=true
    if command -v dnf &> /dev/null; then
        PKG_MANAGER="dnf"
    else
        PKG_MANAGER="yum"
    fi
    WEB_USER="nginx"
    WEB_GROUP="nginx"
    NGINX_CONF_DIR="/etc/nginx/conf.d"
fi
# =======================================================
