#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

ACTION=$1
LOG_FILE="/var/log/wootify_install.log"

log() {
    echo "[REDIS-SERVER] $1"
    echo "[REDIS-SERVER] $1" >> $LOG_FILE
}

source "$(dirname "$0")/os_detect.sh"

if [ "$ACTION" == "install" ]; then
    log "Installing Redis Server..."
    if [ "$IS_DEBIAN" = true ]; then
        apt-get update
        apt-get install -y redis-server
    elif [ "$IS_RHEL" = true ]; then
        $PKG_MANAGER install -y epel-release
        $PKG_MANAGER install -y redis
    fi
    if [ "$IS_DEBIAN" = true ]; then
        systemctl enable redis-server
        systemctl start redis-server
    elif [ "$IS_RHEL" = true ]; then
        systemctl enable redis
        systemctl start redis
    fi
    log "Redis Server installed successfully."

    log "Installing PHP Redis Extension..."
    bash "$(dirname "$0")/manage_extension.sh" install redis

elif [ "$ACTION" == "uninstall" ]; then
    log "Uninstalling Redis Server..."
    if [ "$IS_DEBIAN" = true ]; then
        systemctl stop redis-server || true
        systemctl disable redis-server || true
    elif [ "$IS_RHEL" = true ]; then
        systemctl stop redis || true
        systemctl disable redis || true
    fi
    if [ "$IS_DEBIAN" = true ]; then
        apt-get remove -y redis-server
        apt-get autoremove -y
    elif [ "$IS_RHEL" = true ]; then
        $PKG_MANAGER remove -y redis
    fi
    log "Redis Server uninstalled successfully."

    log "Uninstalling PHP Redis Extension..."
    bash "$(dirname "$0")/manage_extension.sh" uninstall redis

else
    echo "Usage: $0 [install|uninstall]"
    exit 1
fi
