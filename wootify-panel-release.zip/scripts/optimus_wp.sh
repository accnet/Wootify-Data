#!/bin/bash
set -e

DOMAIN=$1
shift

WEB_ROOT="/var/www/$DOMAIN"
LOG_FILE="/var/log/wootify_install.log"

if [ -z "$DOMAIN" ]; then
    echo "Usage: $0 domain [options]"
    exit 1
fi

log() {
    echo "[INFO] $1"
    # Write to log file for websocket stream
    echo "[OPTIMUS] $1" >> $LOG_FILE
}

log "Starting optimization for $DOMAIN..."

cd "$WEB_ROOT"

source "$(dirname "$0")/os_detect.sh"

# Ensure WP-CLI
if ! command -v wp &> /dev/null; then
    curl -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar
    chmod +x wp-cli.phar
    mv wp-cli.phar /usr/local/bin/wp
fi

# Parse Flags
while [ "$#" -gt 0 ]; do
  case "$1" in
    --permalinks)
       log "Enabling Pretty Permalinks..."
       sudo -u $WEB_USER /usr/local/bin/wp rewrite structure '/%postname%/' --path="$WEB_ROOT"
       ;;
    --redis)
       if nc -z localhost 6379; then
           log "Installing Redis Object Cache..."
           sudo -u $WEB_USER /usr/local/bin/wp plugin install redis-cache --activate --path="$WEB_ROOT"
           sudo -u $WEB_USER /usr/local/bin/wp redis enable --path="$WEB_ROOT" || true
       else
           log "Redis service not detected. Skipping."
       fi
       ;;
    --clear-defaults)
       log "Cleaning up defaults and installing Storefront..."
       # Install Storefront
       sudo -u $WEB_USER /usr/local/bin/wp theme install storefront --activate --path="$WEB_ROOT"
       # Delete other themes
       sudo -u $WEB_USER /usr/local/bin/wp theme list --field=name --path="$WEB_ROOT" | grep -v "storefront" | xargs -r sudo -u $WEB_USER /usr/local/bin/wp theme delete --path="$WEB_ROOT"
       # Delete default plugins (Hello Dolly, Akismet)
       sudo -u $WEB_USER /usr/local/bin/wp plugin delete hello akismet --path="$WEB_ROOT" || true
       ;;
    --install-plugins)
       log "Installing Optimus Plugins..."
       PLUGINS="classic-editor classic-widgets contact-form-7 disable-xml-rpc easy-wp-smtp index-wp-mysql-for-speed woocommerce wp-optimize"
       sudo -u $WEB_USER /usr/local/bin/wp plugin install $PLUGINS --activate --path="$WEB_ROOT"
       ;;
    --wp-cron)
       log "Disabling WP-Cron and adding Linux cron..."
       sudo -u $WEB_USER /usr/local/bin/wp config set DISABLE_WP_CRON true --raw --type=constant --path="$WEB_ROOT" || true
       CRON_FILE="/etc/cron.d/wpcron_${DOMAIN//./_}"
       # Ensure cron.d directory exists
       if [ ! -d /etc/cron.d ]; then
           mkdir -p /etc/cron.d
       fi
       echo "*/5 * * * * $WEB_USER curl -s -A 'WootifyPanel' \"http://$DOMAIN/wp-cron.php\" >/dev/null 2>&1" > "$CRON_FILE"
       chmod 644 "$CRON_FILE"
       ;;
  esac
  shift
done

# Always do basic cleanup
log "Doing basic cleanup..."
sudo -u $WEB_USER /usr/local/bin/wp transient delete --all --path="$WEB_ROOT"
sudo -u $WEB_USER /usr/local/bin/wp cache flush --path="$WEB_ROOT"

log "Optimization complete for $DOMAIN."
