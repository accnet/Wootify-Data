#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

ACTION=$1
MODULE=$2

if [ -z "$ACTION" ] || [ -z "$MODULE" ]; then
    echo "Usage: $0 [install|uninstall|status] [module_name]"
    exit 1
fi

LOG_FILE="/var/log/wootify_modules.log"
log() {
    echo "[MODULE:$MODULE] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [MODULE:$MODULE] $1" >> $LOG_FILE
}

source "$(dirname "$0")/os_detect.sh"

status_module() {
    case "$MODULE" in
        firewall)
            if command -v ufw >/dev/null 2>&1; then
                ufw status | grep -q "Status: active" && return 0 || return 1
            elif command -v firewall-cmd >/dev/null 2>&1; then
                systemctl is-active --quiet firewalld && return 0 || return 1
            elif command -v csf >/dev/null 2>&1; then
                csf -l | grep -q "Chain INPUT" && return 0 || return 1
            fi
            return 1
            ;;
        cloudflare)
            [ -f "/etc/nginx/conf.d/cloudflare.conf" ] && return 0 || return 1
            ;;
        rate-limit)
            [ -f "/etc/nginx/conf.d/rate_limit.conf" ] && return 0 || return 1
            ;;
        fail2ban)
            systemctl is-active --quiet fail2ban && return 0 || return 1
            ;;
        php-protect)
            [ -f "/etc/php/wootify-protect.conf" ] && return 0 || [ -f "/etc/opt/remi/wootify-protect.conf" ] && return 0 || return 1
            ;;
        bot-block)
            [ -f "/etc/nginx/conf.d/bot_block.conf" ] && return 0 || return 1
            ;;
        waf)
            if [ "$IS_DEBIAN" = true ]; then
                dpkg-query -W -f='${Status}' "libnginx-mod-http-modsecurity" 2>/dev/null | grep -q "install ok installed" && return 0 || return 1
            else
                rpm -q "nginx-mod-modsecurity" >/dev/null 2>&1 && return 0 || return 1
            fi
            ;;
        emergency)
            [ -f "/etc/nginx/conf.d/emergency_mode.conf" ] && return 0 || return 1
            ;;
        *)
            return 1
            ;;
    esac
}

install_module() {
    log "Enabling module..."
    case "$MODULE" in
        firewall)
            if command -v ufw >/dev/null 2>&1; then
                ufw --force enable
            elif command -v firewall-cmd >/dev/null 2>&1; then
                systemctl enable --now firewalld
            else
                log "No supported firewall found. Please install ufw or firewalld."
                exit 1
            fi
            ;;
        cloudflare)
            cat > /etc/nginx/conf.d/cloudflare.conf << 'EOF'
set_real_ip_from 173.245.48.0/20;
set_real_ip_from 103.21.244.0/22;
set_real_ip_from 103.22.200.0/22;
set_real_ip_from 103.31.4.0/22;
set_real_ip_from 141.101.64.0/18;
set_real_ip_from 108.162.192.0/18;
set_real_ip_from 190.93.240.0/20;
set_real_ip_from 188.114.96.0/20;
set_real_ip_from 197.234.240.0/22;
set_real_ip_from 198.41.128.0/17;
set_real_ip_from 162.158.0.0/15;
set_real_ip_from 104.16.0.0/13;
set_real_ip_from 104.24.0.0/14;
set_real_ip_from 172.64.0.0/13;
set_real_ip_from 131.0.72.0/22;
real_ip_header CF-Connecting-IP;
EOF
            systemctl reload nginx || true
            ;;
        rate-limit)
            cat > /etc/nginx/conf.d/rate_limit.conf << 'EOF'
limit_req_zone $binary_remote_addr zone=global:10m rate=20r/s;
limit_conn_zone $binary_remote_addr zone=addr:10m;
EOF
            systemctl reload nginx || true
            ;;
        fail2ban)
            if [ "$IS_DEBIAN" = true ]; then
                apt-get update && apt-get install -y fail2ban
            else
                $PKG_MANAGER install -y fail2ban
            fi
            systemctl enable --now fail2ban
            ;;
        php-protect)
            touch "/etc/php/wootify-protect.conf" 2>/dev/null || touch "/etc/opt/remi/wootify-protect.conf" 2>/dev/null || true
            log "PHP protection enabled."
            ;;
        bot-block)
            cat > /etc/nginx/conf.d/bot_block.conf << 'EOF'
# Block bad bots
map $http_user_agent $bad_bot {
    default 0;
    ~*(360Spider|80legs|SemrushBot|AhrefsBot|Baiduspider|Bytespider|DotBot|MJ12bot) 1;
}
EOF
            systemctl reload nginx || true
            ;;
        waf)
            log "Installing WAF (ModSecurity)..."
            if [ "$IS_DEBIAN" = true ]; then
                apt-get install -y libnginx-mod-http-modsecurity || true
            else
                $PKG_MANAGER install -y nginx-mod-modsecurity || true
            fi
            ;;
        emergency)
            cat > /etc/nginx/conf.d/emergency_mode.conf << 'EOF'
# Emergency Mode Active
limit_req_zone $binary_remote_addr zone=emergency:10m rate=5r/s;
EOF
            systemctl reload nginx || true
            ;;
        *)
            log "Unknown module: $MODULE"
            exit 1
            ;;
    esac
    log "Module $MODULE installed/enabled successfully."
}

uninstall_module() {
    log "Disabling module..."
    case "$MODULE" in
        firewall)
            if command -v ufw >/dev/null 2>&1; then
                ufw --force disable
            elif command -v firewall-cmd >/dev/null 2>&1; then
                systemctl disable --now firewalld
            fi
            ;;
        cloudflare)
            rm -f /etc/nginx/conf.d/cloudflare.conf
            systemctl reload nginx || true
            ;;
        rate-limit)
            rm -f /etc/nginx/conf.d/rate_limit.conf
            systemctl reload nginx || true
            ;;
        fail2ban)
            systemctl disable --now fail2ban || true
            ;;
        php-protect)
            rm -f "/etc/php/wootify-protect.conf"
            rm -f "/etc/opt/remi/wootify-protect.conf"
            ;;
        bot-block)
            rm -f /etc/nginx/conf.d/bot_block.conf
            systemctl reload nginx || true
            ;;
        waf)
            log "WAF disable not fully implemented."
            ;;
        emergency)
            rm -f /etc/nginx/conf.d/emergency_mode.conf
            systemctl reload nginx || true
            ;;
        *)
            log "Unknown module: $MODULE"
            exit 1
            ;;
    esac
    log "Module $MODULE uninstalled/disabled successfully."
}

if [ "$ACTION" == "status" ]; then
    status_module
    exit $?
elif [ "$ACTION" == "install" ]; then
    # Kiểm tra tương thích: chỉ cho phép cài module nếu LEMP (Nginx) đã được thiết lập
    if ! command -v nginx >/dev/null 2>&1; then
        log "Lỗi: LEMP stack chưa được cài đặt. Không thể cài module."
        echo "ERROR: LEMP stack required"
        exit 1
    fi
    install_module
elif [ "$ACTION" == "uninstall" ]; then
    uninstall_module
else
    echo "Invalid action"
    exit 1
fi
