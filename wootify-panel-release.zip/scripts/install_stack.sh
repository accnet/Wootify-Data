#!/bin/bash
set -e

# Error Handling
trap 'echo "[ERROR] Installation failed on line $LINENO"; exit 1' ERR

# Configuration
export DEBIAN_FRONTEND=noninteractive
PHP_VERSION=${PHP_VERSION:-"8.2"}
LOG_FILE="/var/log/wootify_install.log"

# Colors (Not used in log function but kept for reference)
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

source "$(dirname "$0")/os_detect.sh"

# Helper Functions
log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> $LOG_FILE
}

progress() {
    echo "[PROGRESS] $1"
}

retry() {
    local n=1
    local max=3
    local delay=5
    while true; do
        "$@" && break || {
            local exit_code=$?
            if [[ $exit_code -eq 137 || $exit_code -eq 130 ]]; then
                log "Process was killed or interrupted (Code: $exit_code). This usually means Out-Of-Memory."
                # We don't return here to allow the outer loop to retry or fail
            fi
            
            if [[ $n -lt $max ]]; then
                ((n++))
                log "Command failed. Retrying in $delay seconds ($n/$max)..."
                sleep $delay;
            else
                log "Command failed after $n attempts."
                return 1
            fi
        }
    done
}

# Ensure minimum swap for stable installation on low RAM VPS
ensure_swap() {
    local ram_kb=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    local swap_kb=$(grep SwapTotal /proc/meminfo | awk '{print $2}')
    
    if [ "$ram_kb" -lt 2000000 ] && [ "$swap_kb" -lt 500000 ]; then
        log "Low RAM detected ($((ram_kb/1024))MB) and no/low swap. Creating 1GB temporary swap for stable installation..."
        if [ ! -f /wootify_tmp_swap ]; then
            fallocate -l 1G /wootify_tmp_swap || dd if=/dev/zero of=/wootify_tmp_swap bs=1M count=1024
            chmod 600 /wootify_tmp_swap
            mkswap /wootify_tmp_swap
            swapon /wootify_tmp_swap
            log "Temporary swap enabled."
        fi
    fi
}

optimize_sysctl() {
    log "Optimizing system limits..."
    cat > /etc/sysctl.d/99-wootify.conf <<EOF
fs.file-max = 100000
net.core.somaxconn = 4096
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_tw_reuse = 1
EOF
    sysctl -p /etc/sysctl.d/99-wootify.conf || true
}

optimize_nginx() {
    log "Tuning Nginx configuration..."
    # Increase body size and timeouts
    sed -i 's/client_max_body_size .*/client_max_body_size 100M;/g' /etc/nginx/nginx.conf 2>/dev/null || \
    sed -i '/http {/a \    client_max_body_size 100M;' /etc/nginx/nginx.conf
    
    # Enable Gzip
    sed -i 's/# gzip on;/gzip on;/g' /etc/nginx/nginx.conf
    
    systemctl restart nginx
}

optimize_php() {
    log "Tuning PHP $PHP_VERSION configuration..."
    if [ "$IS_DEBIAN" = true ]; then
        PHP_INI="/etc/php/$PHP_VERSION/fpm/php.ini"
    elif [ "$IS_RHEL" = true ]; then
        PHP_INI="/etc/php.ini"
    fi
    
    if [ -f "$PHP_INI" ]; then
        sed -i 's/memory_limit = .*/memory_limit = 256M/g' $PHP_INI
        sed -i 's/upload_max_filesize = .*/upload_max_filesize = 100M/g' $PHP_INI
        sed -i 's/post_max_size = .*/post_max_size = 100M/g' $PHP_INI
        sed -i 's/max_execution_time = .*/max_execution_time = 300/g' $PHP_INI
    fi
    
    if [ "$IS_DEBIAN" = true ]; then
        systemctl restart php$PHP_VERSION-fpm
    elif [ "$IS_RHEL" = true ]; then
        systemctl restart php-fpm
    fi
}

# --- Main Installation ---

force_unlock_dpkg() {
    log "Checking for stuck package manager processes..."
    
    # Kill running apt/dpkg processes (requires psmisc)
    # We use lsof or fuser if available, else pkill
    killall apt apt-get dpkg > /dev/null 2>&1 || true
    
    # Remove lock files
    rm -f /var/lib/dpkg/lock
    rm -f /var/lib/dpkg/lock-frontend
    rm -f /var/cache/apt/archives/lock
    
    # Repair
    log "Repairing package manager state..."
    dpkg --configure -a || true
}

# --- Main Installation ---

progress 5
log "Initializing installation..."
ensure_swap

# Unlock and repair package manager
if [ "$IS_DEBIAN" = true ]; then
    force_unlock_dpkg
elif [ "$IS_RHEL" = true ]; then
    log "Checking for stuck $PKG_MANAGER processes..."
    rm -f /var/run/yum.pid
fi

progress 10
log "Updating system repositories..."
if [ "$IS_DEBIAN" = true ]; then
    retry apt-get update -y
    log "Installing base dependencies..."
    retry apt-get install -y curl wget unzip gnupg2 ca-certificates lsb-release psmisc netcat-openbsd
elif [ "$IS_RHEL" = true ]; then
    log "Installing base dependencies for RHEL..."
    retry $PKG_MANAGER install -y epel-release
    retry $PKG_MANAGER install -y curl wget unzip ca-certificates nmap-ncat
    
    # Configure SELinux to permissive mode to allow panel operations
    log "Configuring SELinux..."
    if command -v setenforce &> /dev/null; then
        setenforce 0 || true
        if [ -f /etc/selinux/config ]; then
            sed -i 's/^SELINUX=.*/SELINUX=permissive/g' /etc/selinux/config || true
        fi
    fi
fi

progress 20
if [ "$INSTALL_NGINX" = "true" ]; then
    log "Installing Nginx Web Server..."
    retry $PKG_MANAGER install -y nginx
    systemctl enable nginx
    systemctl start nginx
    optimize_nginx
else
    log "Skipping Nginx..."
fi

progress 50
if [ "$IS_DEBIAN" = true ]; then
    log "Configuring PHP repositories for Debian/Ubuntu..."
    if ! grep -q "ondrej/php" /etc/apt/sources.list.d/*; then
        retry apt-get install -y software-properties-common
        retry add-apt-repository ppa:ondrej/php -y
        retry apt-get update -y
    fi

    log "Installing PHP $PHP_VERSION and extensions..."
    retry apt-get install -y \
        php$PHP_VERSION php$PHP_VERSION-fpm php$PHP_VERSION-mysql \
        php$PHP_VERSION-common php$PHP_VERSION-cli php$PHP_VERSION-curl \
        php$PHP_VERSION-mbstring php$PHP_VERSION-xml php$PHP_VERSION-zip \
        php$PHP_VERSION-bcmath php$PHP_VERSION-intl php$PHP_VERSION-gd \
        php$PHP_VERSION-imagick php$PHP_VERSION-opcache

    systemctl enable php$PHP_VERSION-fpm
    systemctl start php$PHP_VERSION-fpm
    optimize_php
elif [ "$IS_RHEL" = true ]; then
    log "Configuring PHP repositories for RHEL..."
    # Install Remi repository
    MAJOR_VER=$(echo $VERSION_ID | cut -d. -f1)
    retry $PKG_MANAGER install -y https://rpms.remirepo.net/enterprise/remi-release-${MAJOR_VER}.rpm
    
    # Clean PHP $PHP_VERSION format (e.g. 8.2 -> 82)
    PHP_VER_SHORT=$(echo $PHP_VERSION | tr -d '.')
    
    log "Installing PHP $PHP_VERSION from Remi repository..."
    if [[ "$MAJOR_VER" == "9" || "$MAJOR_VER" == "8" ]]; then
        $PKG_MANAGER module reset php -y
        $PKG_MANAGER module enable php:remi-$PHP_VERSION -y
        retry $PKG_MANAGER install -y \
            php php-fpm php-mysqlnd php-common php-cli php-curl \
            php-mbstring php-xml php-zip php-bcmath php-intl \
            php-gd php-imagick php-opcache cronie crontabs
    else
        retry $PKG_MANAGER install -y \
            php$PHP_VER_SHORT-php-fpm php$PHP_VER_SHORT-php-mysqlnd \
            php$PHP_VER_SHORT-php-common php$PHP_VER_SHORT-php-cli \
            php$PHP_VER_SHORT-php-curl php$PHP_VER_SHORT-php-mbstring \
            php$PHP_VER_SHORT-php-xml php$PHP_VER_SHORT-php-zip \
            php$PHP_VER_SHORT-php-bcmath php$PHP_VER_SHORT-php-intl \
            php$PHP_VER_SHORT-php-gd php$PHP_VER_SHORT-php-imagick \
            php$PHP_VER_SHORT-php-opcache cronie crontabs
    fi

    systemctl enable crond
    systemctl start crond

    systemctl enable php-fpm
    
    # Set user/group to appropriate web user in php-fpm on RHEL
    if [ -f /etc/php-fpm.d/www.conf ]; then
        sed -i "s/user = apache/user = $WEB_USER/" /etc/php-fpm.d/www.conf
        sed -i "s/group = apache/group = $WEB_GROUP/" /etc/php-fpm.d/www.conf
        sed -i "s/;listen.owner = nobody/listen.owner = $WEB_USER/" /etc/php-fpm.d/www.conf
        sed -i "s/;listen.group = nobody/listen.group = $WEB_GROUP/" /etc/php-fpm.d/www.conf
        sed -i 's/;listen.mode = 0660/listen.mode = 0660/' /etc/php-fpm.d/www.conf
    fi

    systemctl start php-fpm
    optimize_php
fi

progress 80
if [ "$INSTALL_MARIADB" = "true" ]; then
    log "Installing MariaDB Database..."
    if [ "$IS_DEBIAN" = true ]; then
        retry apt-get install -y mariadb-server mariadb-client
    elif [ "$IS_RHEL" = true ]; then
        retry $PKG_MANAGER install -y mariadb-server mariadb
    fi
    systemctl enable mariadb
    systemctl start mariadb
else
    log "Skipping MariaDB..."
fi

progress 90
log "Optimizing system kernel parameters..."
optimize_sysctl

log "Cleaning up package cache..."
if [ "$IS_DEBIAN" = true ]; then
    apt-get autoremove -y
    apt-get clean
elif [ "$IS_RHEL" = true ]; then
    $PKG_MANAGER autoremove -y
    $PKG_MANAGER clean all
fi

progress 100
log "Installation Completed Successfully!"
