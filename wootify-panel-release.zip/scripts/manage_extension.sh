#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

ACTION=$1
EXTENSION=$2
# Dynamic PHP Version Detection
PHP_VERSIONS=($(ls /etc/php 2>/dev/null | grep -E '^[0-9]+\.[0-9]+$'))
if [ ${#PHP_VERSIONS[@]} -eq 0 ]; then
    PHP_VERSIONS=("8.1" "8.2" "8.3")
fi

if [ -z "$ACTION" ] || [ -z "$EXTENSION" ]; then
    echo "Usage: $0 [install|uninstall] [extension_name]"
    exit 1
fi

LOG_FILE="/var/log/wootify_install.log"
log() {
    echo "[EXTENSIONS] $1"
    echo "[EXTENSIONS] $1" >> $LOG_FILE
}

# Map UI names to Package names
case "$EXTENSION" in
    redis)
        PKG_SUFFIX="redis"
        ;;
    opcache)
        PKG_SUFFIX="opcache"
        ;;
    imagick)
        PKG_SUFFIX="imagick"
        ;;
    *)
        log "Unknown extension: $EXTENSION"
        exit 1
        ;;
esac

log "Starting $ACTION for $EXTENSION..."

source "$(dirname "$0")/os_detect.sh"

if [ "$ACTION" == "install" ]; then
    for ver in "${PHP_VERSIONS[@]}"; do
        if [ "$IS_DEBIAN" = true ]; then
            if dpkg-query -W -f='${Status}' "php$ver-common" 2>/dev/null | grep -q "install ok installed"; then
                log "Installing php$ver-$PKG_SUFFIX..."
                apt-get install -y "php$ver-$PKG_SUFFIX"
                
                if systemctl is-active --quiet "php$ver-fpm"; then
                    systemctl restart "php$ver-fpm"
                    log "Restarted php$ver-fpm"
                fi
            fi
        elif [ "$IS_RHEL" = true ]; then
            # Simplistic for RHEL: assuming format php-extension
            log "Installing php-$PKG_SUFFIX on RHEL..."
            $PKG_MANAGER install -y php-$PKG_SUFFIX || true
            systemctl restart php-fpm || true
        fi
    done
    log "$EXTENSION installed successfully."

elif [ "$ACTION" == "uninstall" ]; then
    for ver in "${PHP_VERSIONS[@]}"; do
        if [ "$IS_DEBIAN" = true ]; then
            if dpkg-query -W -f='${Status}' "php$ver-common" 2>/dev/null | grep -q "install ok installed"; then
                log "Removing php$ver-$PKG_SUFFIX..."
                apt-get remove -y "php$ver-$PKG_SUFFIX"
                
                if systemctl is-active --quiet "php$ver-fpm"; then
                    systemctl restart "php$ver-fpm"
                    log "Restarted php$ver-fpm"
                fi
            fi
        elif [ "$IS_RHEL" = true ]; then
            log "Removing php-$PKG_SUFFIX on RHEL..."
            $PKG_MANAGER remove -y php-$PKG_SUFFIX || true
            systemctl restart php-fpm || true
        fi
    done
    log "$EXTENSION uninstalled successfully."

else
    log "Invalid action: $ACTION"
    exit 1
fi
