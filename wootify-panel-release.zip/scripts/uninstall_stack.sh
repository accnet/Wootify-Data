#!/bin/bash
set -e

# Configuration
export DEBIAN_FRONTEND=noninteractive
LOG_FILE="/var/log/wootify_uninstall.log"

# Helper Functions
log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> $LOG_FILE
}

progress() {
    echo "[PROGRESS] $1"
}

source "$(dirname "$0")/os_detect.sh"

# Error Handling
trap 'echo "[ERROR] Uninstallation failed on line $LINENO"; exit 1' ERR

# --- Main Uninstallation ---

progress 5
log "Initializing uninstallation..."
log "WARNING: This will remove Nginx, PHP (all versions), and MariaDB binaries."

progress 10
log "Stopping services..."
systemctl stop nginx > /dev/null 2>&1 || true
systemctl stop mariadb > /dev/null 2>&1 || true
# Stop all PHP-FPM services
pkill -f php-fpm > /dev/null 2>&1 || true

progress 30
log "Removing Nginx Web Server..."
if [ "$IS_DEBIAN" = true ]; then
    apt-get remove --purge -y nginx nginx-common nginx-core > /dev/null 2>&1 || true
elif [ "$IS_RHEL" = true ]; then
    $PKG_MANAGER remove -y nginx > /dev/null 2>&1 || true
fi

progress 50
log "Removing PHP and Extensions..."
# Remove Redis Server and specific extensions explicitly first
if [ "$IS_DEBIAN" = true ]; then
    systemctl stop redis-server > /dev/null 2>&1 || true
    apt-get remove --purge -y redis-server "php*-redis" "php*-imagick" "php*-opcache" > /dev/null 2>&1 || true
    # Remove all PHP versions
    apt-get remove --purge -y "php*" > /dev/null 2>&1 || true
elif [ "$IS_RHEL" = true ]; then
    systemctl stop redis > /dev/null 2>&1 || true
    $PKG_MANAGER remove -y redis php-redis php-imagick php-opcache > /dev/null 2>&1 || true
    $PKG_MANAGER remove -y "php*" > /dev/null 2>&1 || true
fi

progress 70
log "Removing MariaDB Database..."
if [ "$IS_DEBIAN" = true ]; then
    apt-get remove --purge -y mariadb-server mariadb-client "mysql*" > /dev/null 2>&1 || true
elif [ "$IS_RHEL" = true ]; then
    $PKG_MANAGER remove -y mariadb-server mariadb > /dev/null 2>&1 || true
fi
# Note: We do NOT remove /var/lib/mysql automatically to preserve data safety,
# unless the user manually deleted it.

progress 90
log "Cleaning up system packages..."
if [ "$IS_DEBIAN" = true ]; then
    apt-get autoremove -y > /dev/null 2>&1
    apt-get clean > /dev/null 2>&1
elif [ "$IS_RHEL" = true ]; then
    $PKG_MANAGER autoremove -y > /dev/null 2>&1
    $PKG_MANAGER clean all > /dev/null 2>&1
fi

log "Resetting VPS optimization state markers (PHP/MariaDB/Nginx)..."
# PHP optimization markers (Debian)
find /etc/php -type f -name "www.conf.bak" -delete > /dev/null 2>&1 || true
# PHP optimization markers (RHEL)
rm -f /etc/php-fpm.d/www.conf.bak > /dev/null 2>&1 || true

# MariaDB optimization markers
rm -f /etc/mysql/mariadb.conf.d/50-server.cnf.bak > /dev/null 2>&1 || true
rm -f /etc/mysql/mariadb.conf.d/99-wootify-custom.cnf > /dev/null 2>&1 || true
rm -f /etc/my.cnf.d/mariadb-server.cnf.bak > /dev/null 2>&1 || true
rm -f /etc/my.cnf.d/99-wootify-custom.cnf > /dev/null 2>&1 || true

# Nginx optimization markers
rm -f /etc/nginx/nginx.conf.bak > /dev/null 2>&1 || true

# Remove config directories
rm -rf /etc/nginx > /dev/null 2>&1 || true
rm -rf /etc/php > /dev/null 2>&1 || true
rm -rf /etc/php-fpm.d > /dev/null 2>&1 || true

progress 100
log "Uninstallation Completed Successfully!"
