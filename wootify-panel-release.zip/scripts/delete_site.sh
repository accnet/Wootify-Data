#!/bin/bash
set -e

DOMAIN=$1
WEB_ROOT="/var/www/$DOMAIN"
LOG_FILE="/var/log/wootify_sites.log"

log() {
    echo "[INFO] $1"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [INFO] $1" >> $LOG_FILE
}

log "Deleting site $DOMAIN..."

find_cert_names_by_domain() {
    certbot certificates 2>/dev/null | awk -v d="$DOMAIN" '
        /Certificate Name:/ {name=$3}
        /Domains:/ {
            for (i=2; i<=NF; i++) {
                if ($i == d || $i == "www." d) {
                    print name
                    break
                }
            }
        }
    ' | sort -u
}

source "$(dirname "$0")/os_detect.sh"

# 1. Get DB Info and Drop Database
if [ -f "$WEB_ROOT/wp-config.php" ]; then
    DB_NAME=$(grep "DB_NAME" "$WEB_ROOT/wp-config.php" | cut -d "'" -f 4)
    DB_USER=$(grep "DB_USER" "$WEB_ROOT/wp-config.php" | cut -d "'" -f 4)
    
    if [ ! -z "$DB_NAME" ]; then
        log "Dropping database $DB_NAME..."
        mariadb -e "DROP DATABASE IF EXISTS \`$DB_NAME\`;" || true
    fi
    if [ ! -z "$DB_USER" ]; then
        log "Dropping user $DB_USER..."
        mariadb -e "DROP USER IF EXISTS '$DB_USER'@'localhost';" || true
    fi
    mariadb -e "FLUSH PRIVILEGES;" || true
else
    log "wp-config.php not found. Skipping database cleanup."
fi

# 2. Remove Nginx Config
NGINX_CONF="$NGINX_CONF_DIR/$DOMAIN.conf"
if [ "$IS_DEBIAN" = true ]; then
    NGINX_CONF="/etc/nginx/sites-available/$DOMAIN"
    rm -f "/etc/nginx/sites-enabled/$DOMAIN"
fi

if [ -f "$NGINX_CONF" ]; then
    log "Removing Nginx configuration at $NGINX_CONF..."
    rm -f "$NGINX_CONF"
    
    if nginx -t; then
        systemctl reload nginx
    else
        log "Nginx config error after deletion. Please check manually."
    fi
fi

# 2.1 Remove Let's Encrypt certificate/renewal data for this domain (if exists)
if command -v certbot &> /dev/null; then
    EXISTING_CERTS=$(find_cert_names_by_domain || true)
    if [ -n "$EXISTING_CERTS" ]; then
        log "Removing Let's Encrypt certificate lineage(s) for $DOMAIN..."
        while IFS= read -r CERT_NAME; do
            [ -z "$CERT_NAME" ] && continue
            certbot delete --cert-name "$CERT_NAME" --non-interactive || true
        done <<< "$EXISTING_CERTS"
    fi
fi

rm -f "/etc/letsencrypt/renewal/${DOMAIN}.conf"
rm -rf "/etc/letsencrypt/live/${DOMAIN}"
rm -rf "/etc/letsencrypt/archive/${DOMAIN}"

# 3. Remove Web Directory
if [ -d "$WEB_ROOT" ]; then
    log "Removing web directory $WEB_ROOT..."
    rm -rf "$WEB_ROOT"
fi

# Remove log files
rm -f "/var/log/nginx/${DOMAIN}_access.log"
rm -f "/var/log/nginx/${DOMAIN}_error.log"

log "Site $DOMAIN deleted successfully."
